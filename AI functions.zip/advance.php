<?php
/* ============================================================
   BACKEND CLEAN JSON HANDLER — FIXED
============================================================ */
ob_start();

if (isset($_POST["action"]) && $_POST["action"] === "analyze") {

    header("Content-Type: application/json; charset=utf-8");

    $OPENAI_KEY = " PUT your API key"; // your API key here

    $messages = json_decode($_POST["messages"] ?? "", true);
    if (!$messages) {
        ob_end_clean();
        echo json_encode(["backend_error" => "Invalid messages"]);
        exit;
    }

    $payload = json_encode([
        "model" => "gpt-4o", // FIXED
        "messages" => $messages
    ]);

    $ch = curl_init("https://api.openai.com/v1/chat/completions");
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            "Authorization: Bearer $OPENAI_KEY",
            "Content-Type: application/json"
        ],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS => $payload
    ]);

    $response = curl_exec($ch);
    $curl_err = curl_error($ch);
    curl_close($ch);

    ob_end_clean();
    if ($curl_err) { echo json_encode(["curl_error" => $curl_err]); exit; }

    echo $response;
    exit;
}

ob_end_clean();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Cosmetic AI (iOS Edition)</title>
<meta name="viewport" content="width=device-width, initial-scale=1">



<!-- iOS FONT -->
<link href="https://fonts.googleapis.com/css2?family:Inter:wght@300;400;500;600&display=swap" rel="stylesheet">

<!-- Icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">


<style>

/* ----------------------------------------
   GLOBAL iOS RESET
---------------------------------------- */
html, body {
    margin:0;
    padding:0;
    background:#f8f8f9;
    font-family:-apple-system, BlinkMacSystemFont, "SF Pro Display", "Inter", sans-serif;
    overscroll-behavior-y: none;
    padding-bottom: 85px;
}

* {
    box-sizing:border-box;
}

/* ----------------------------------------
   SCREEN CONTAINER
---------------------------------------- */
.screen {
    display:none;
    max-width:500px;
    margin:auto;
    padding:16px;
}
.screen.active {
    display:block;
}

/* ----------------------------------------
   CARD (iOS GLASS STYLE)
---------------------------------------- */
.card {
    background:#fff;
    padding:18px;
    border-radius:18px;
    box-shadow:0 4px 14px rgba(0,0,0,0.06);
    margin-bottom:18px;
}

/* ----------------------------------------
   TITLES
---------------------------------------- */
h2 {
    margin:10px 0 16px;
    text-align:center;
    font-size:20px;
    font-weight:600;
    color:#111;
}

.section-title {
    font-size:14px;
    font-weight:600;
    color:#6b7280;
    margin-bottom:8px;
    letter-spacing:0.02em;
}

/* ----------------------------------------
   SELECT (iOS STYLE)
---------------------------------------- */
select {
    width:100%;
    padding:12px 14px;
    border-radius:10px;
    border:1px solid #d1d5db;
    background:#f9fafb;
    font-size:15px;
    color:#333;
    appearance:none;
}

/* ----------------------------------------
   iOS SMALL BUTTONS — COMPACT (Option A)
---------------------------------------- */
.btn {
    width:100%;
    padding:10px;  /* Compact */
    border:none;
    border-radius:12px;
    font-size:14px;
    font-weight:600;
    color:#fff;
    cursor:pointer;
    margin:6px 0;
    transition:0.2s;
}

.btn:active {
    opacity:0.7;
    transform:scale(0.98);
}

.btn-green { background:#10b981; }
.btn-blue  { background:#2563eb; }
.btn-purple{ background:#7c3aed; }
.btn-gray  { background:#6b7280; }
.btn-teal  { background:#0d9488; }

/* ----------------------------------------
   IMAGE PREVIEW
---------------------------------------- */
#imagesPreview img {
    width:100%;
    border-radius:16px;
    margin-top:10px;
}

/* ----------------------------------------
   iOS PRE OUTPUT BOX
---------------------------------------- */
pre {
    background:#f1f5f9;
    padding:14px;
    border-radius:14px;
    font-size:14px;
    white-space:pre-wrap;
    line-height:1.5;
    color:#111;
}

/* ----------------------------------------
   RATING BARS
---------------------------------------- */
.rating-line { margin-bottom:12px; }
.rating-label { font-size:13px; font-weight:600; color:#374151; margin-bottom:4px; }

.rating-bar {
    width:100%;
    height:10px;
    background:#e5e7eb;
    border-radius:8px;
    overflow:hidden;
}
.rating-fill {
    height:100%;
    border-radius:8px;
    transition:width .35s ease;
}

/* ----------------------------------------
   iOS NAVBAR
---------------------------------------- */
.navbar {
    position:fixed;
    bottom:0;
    left:0;
    width:100%;
    background:#fff;
    height:70px;
    display:flex;
    justify-content:space-around;
    align-items:center;
    border-top:1px solid #ddd;
    box-shadow:0 -2px 10px rgba(0,0,0,0.06);
    z-index:10000;
}

.nav-item {
    text-align:center;
    font-size:12px;
    color:#6b7280;
    cursor:pointer;
}

.nav-item i {
    display:block;
    font-size:20px;
    margin-bottom:4px;
}

.nav-item.active {
    color:#2563eb;
    font-weight:600;
}

/* ----------------------------------------
   iOS LOADER
---------------------------------------- */
#loader {
    display:none;
    text-align:center;
    margin:12px 0;
}

.spinner {
    width:32px;
    height:32px;
    border:3px solid #cbd5e1;
    border-top-color:#2563eb;
    border-radius:50%;
    animation:spin 0.7s linear infinite;
    margin:auto;
}
@keyframes spin {
    to { transform:rotate(360deg); }
}

/* ----------------------------------------
   iOS TOAST
---------------------------------------- */
#toast {
    display:none;
    position:fixed;
    bottom:90px;
    left:50%;
    transform:translateX(-50%);
    padding:12px 18px;
    background:#111;
    color:#fff;
    font-size:14px;
    border-radius:12px;
    z-index:99999;
    opacity:0;
    transition:opacity .3s;
}

</style>
</head>
<body>
<!-- ============================================================
     SCREEN 1 — IMAGE ANALYSIS (iOS)
============================================================ -->
<div id="screen-image" class="screen active">

    <h2>Image Analysis</h2>

    <!-- CATEGORY SELECT -->
    <div class="card">
        <div class="section-title">Select Category</div>

        <select id="analysisType">
            <option value="">-- Choose --</option>
            <option value="face">Face Features</option>
            <option value="hair">Hair</option>
            <option value="skin">Skin</option>
            <option value="nose">Nose</option>
            <option value="teeth">Teeth</option>
            <option value="cosmetic">General Visible</option>
            <option value="medicine">Medicine</option>
        </select>
    </div>

    <!-- IMAGE INPUT -->
    <div class="card">
        <div class="section-title">Upload or Take Photo</div>

        <label class="btn btn-teal" for="cameraInput">
            <i class="fa fa-camera"></i> Take Photo
        </label>
        <input id="cameraInput" type="file" accept="image/*" capture="environment" hidden>

        <label class="btn btn-blue" for="galleryInput">
            <i class="fa fa-image"></i> Upload Image
        </label>
        <input id="galleryInput" type="file" accept="image/*" hidden>

        <div id="imagesPreview"></div>
    </div>

    <!-- ANALYZE BUTTON -->
    <button id="analyzeImageBtn" class="btn btn-green">
        Analyze Image
    </button>

    <!-- LOADER -->
    <div id="loader">
        <div class="spinner"></div>
    </div>

    <!-- OUTPUT -->
    <div class="card">
        <div class="section-title">Result</div>

        <pre id="imgOutput">No result yet...</pre>

        <div id="ratingBars"></div>

        <button id="speakImgBtn" class="btn btn-purple">🔊 Read</button>
        <button id="copyImgBtn" class="btn btn-gray">📋 Copy</button>
    </div>

</div>



<!-- ============================================================
     SCREEN 2 — VIDEO ANALYSIS (iOS)
============================================================ -->
<div id="screen-video" class="screen">

    <h2>Video Analysis</h2>

    <!-- VIDEO INPUT -->
    <div class="card">
        <div class="section-title">Upload or Record Video</div>

        <label class="btn btn-purple" for="recordVideoInput">
            <i class="fa fa-video"></i> Record Video
        </label>
        <input id="recordVideoInput" type="file" accept="video/*" capture="camcorder" hidden>

        <label class="btn btn-gray" for="videoInput">
            <i class="fa fa-upload"></i> Upload Video
        </label>
        <input id="videoInput" type="file" accept="video/*" hidden>

        <video id="videoPreview" controls style="width:100%; border-radius:14px; margin-top:12px;"></video>
    </div>

    <!-- ANALYZE BUTTON -->
    <button id="analyzeVideoBtn" class="btn btn-green">
        Analyze Video
    </button>

    <!-- OUTPUT -->
    <div class="card">
        <div class="section-title">Result</div>

        <pre id="videoOutput">No video analyzed yet...</pre>

        <div id="ratingBarsVideo"></div>

        <button id="speakVideoBtn" class="btn btn-purple">🔊 Read</button>
        <button id="copyVideoBtn" class="btn btn-gray">📋 Copy</button>

    </div>
</div>




<!-- ============================================================
     iOS NAV-BAR (BOTTOM TABS)
============================================================ -->
<div class="navbar">

    <div class="nav-item active" onclick="switchScreen('image')">
        <i class="fa fa-image"></i>
        Image
    </div>

    <div class="nav-item" onclick="switchScreen('video')">
        <i class="fa fa-video"></i>
        Video
    </div>

    <div class="nav-item" onclick="window.location.href='pdfsummarize.php'">
        <i class="fa fa-file-pdf"></i>
        PDF
    </div>

    <div class="nav-item" onclick="window.location.href='legalresponse.php'">
        <i class="fa fa-balance-scale"></i>
        Legal
    </div>

</div>


<!-- ============================================================
     iOS TOAST
============================================================ -->
<div id="toast"></div>

<footer class="custom-footer">
        <div class="footer-content">
            <i class="fas fa-code"></i>
            <span>Developer:</span>
            <span class="dev-name">Mohammed Basim</span>
            <span class="year">- 2025</span>
        </div>
    </footer>
<script>
/* ============================================================
   iOS TOAST
============================================================ */
function showToast(msg) {
    const t = document.getElementById("toast");
    t.innerText = msg;
    t.style.display = "block";
    setTimeout(() => t.style.opacity = 1, 10);

    setTimeout(() => {
        t.style.opacity = 0;
        setTimeout(() => (t.style.display = "none"), 300);
    }, 2200);
}



/* ============================================================
   NAVIGATION — iOS TABS
============================================================ */
function switchScreen(screen) {
    document.querySelectorAll(".screen")
        .forEach(s => s.classList.remove("active"));

    document.getElementById("screen-" + screen).classList.add("active");

    document.querySelectorAll(".nav-item")
        .forEach(n => n.classList.remove("active"));

    event.target.closest(".nav-item").classList.add("active");
}



/* ============================================================
   BASIC REFERENCES
============================================================ */
const cameraInput      = document.getElementById("cameraInput");
const galleryInput     = document.getElementById("galleryInput");
const videoInput       = document.getElementById("videoInput");
const recordVideoInput = document.getElementById("recordVideoInput");
const videoPreview     = document.getElementById("videoPreview");



/* ============================================================
   FILE → BASE64
============================================================ */
function toBase64(file) {
    return new Promise((resolve, reject) => {
        const r = new FileReader();
        r.onload  = () => resolve(r.result.split(",")[1]);
        r.onerror = reject;
        r.readAsDataURL(file);
    });
}



/* ============================================================
   SAFE OPENAI CALL (FIXED)
============================================================ */
async function callAI(messages) {
    try {
        const res = await fetch("", {
            method: "POST",
            body: new URLSearchParams({
                action: "analyze",
                messages: JSON.stringify(messages)
            })
        });

        const raw = await res.text();

        try {
            const json = JSON.parse(raw);
            return json.choices?.[0]?.message?.content || "❌ No content returned";
        } catch {
            return "❌ SERVER RETURNED NON-JSON:\n\n" + raw.substring(0, 300);
        }

    } catch (e) {
        return "❌ Network Error:\n" + e.toString();
    }
}



/* ============================================================
   IMAGE RESIZE (OPTIONAL)
============================================================ */
async function convertAndResizeToJpeg(file, max = 900) {
    return new Promise(resolve => {
        const reader = new FileReader();
        reader.onload = e => {
            const img = new Image();
            img.onload = () => {
                let w = img.width, h = img.height;

                if (w > h && w > max) { h = h * max / w; w = max; }
                else if (h >= w && h > max) { w = w * max / h; h = max; }

                const canvas = document.createElement("canvas");
                canvas.width = w;
                canvas.height = h;

                const ctx = canvas.getContext("2d");
                ctx.drawImage(img, 0, 0, w, h);

                canvas.toBlob(b => {
                    resolve(new File([b], "image.jpg", { type: "image/jpeg" }));
                }, "image/jpeg", 0.85);
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(file);
    });
}



/* ============================================================
   IMAGE HANDLING
============================================================ */
let imageFile = null;

cameraInput.addEventListener("change", async e => {
    const file = e.target.files[0];
    if (!file) return;
    imageFile = await convertAndResizeToJpeg(file);
    showImage(imageFile);
});

galleryInput.addEventListener("change", async e => {
    const file = e.target.files[0];
    if (!file) return;
    imageFile = await convertAndResizeToJpeg(file);
    showImage(imageFile);
});

function showImage(file) {
    const container = document.getElementById("imagesPreview");
    container.innerHTML = "";

    const reader = new FileReader();
    reader.onload = e => {
        const img = new Image();
        img.src = e.target.result;
        img.style.width = "100%";
        img.style.borderRadius = "14px";
        container.appendChild(img);
    };
    reader.readAsDataURL(file);
}



/* ============================================================
   PROMPTS — SAME AS YOUR VERSION
============================================================ */
const PROMPTS = {
    face: `
Describe ONLY visible face features: symmetry, shape, lighting.
After description, provide rating bars:
- Symmetry Score (0–100%)
- Clarity Score (0–100%)
- Lighting Score (0–100%)
- Confidence Level (0–100%)
`,

    hair: `
you are hair specialist , Describe visible hair
`,

    skin: `
    Describe visible skin: texture, pores, tone, lighting. provide feedback
`,

    nose: `
 Describe only visible nose, detailed.
`,

    teeth: `
Describe only visible teeth, some detail.
`,

    cosmetic: `
Describe EVERYTHING in the image: objects, lighting, colors, face.
`,

    medicine: `
Identify medicine ONLY if visible.
Describe it function.
`
};



/* ============================================================
   RATING BARS PARSER
============================================================ */
function renderRatingBars(text) {
    const container = document.getElementById("ratingBars");
    container.innerHTML = "";

    const regex = /([A-Za-z\s\/\-]+)\s*[:\-]\s*(\d{1,3})%/g;
    let match;

    while ((match = regex.exec(text)) !== null) {
        const label = match[1].trim();
        const value = Number(match[2]);

        let color = "#dc2626";
        if (value > 70) color = "#16a34a";
        else if (value > 40) color = "#f59e0b";

        container.innerHTML += `
        <div class="rating-line">
            <div class="rating-label">${label}: ${value}%</div>
            <div class="rating-bar">
                <div class="rating-fill" style="width:${value}%; background:${color};"></div>
            </div>
        </div>`;
    }
}



/* ============================================================
   ANALYZE IMAGE
============================================================ */
document.getElementById("analyzeImageBtn").addEventListener("click", async () => {

    const type = document.getElementById("analysisType").value;
    const out = document.getElementById("imgOutput");

    if (!type)  return showToast("Select a category");
    if (!imageFile) return showToast("Upload image first");

    showToast("Analyzing...");
    document.getElementById("loader").style.display = "block";
    out.textContent = "Analyzing…";
    document.getElementById("ratingBars").innerHTML = "";

    const base64 = await toBase64(imageFile);

    const result = await callAI([
        {
            role: "user",
            content: [
                { type: "text", text: PROMPTS[type] },
                { type: "image_url", image_url: { url: "data:image/jpeg;base64," + base64 } }
            ]
        }
    ]);

    document.getElementById("loader").style.display = "none";
    out.textContent = result;

    renderRatingBars(result);

    showToast("Done");
});



/* ============================================================
   VIDEO HANDLING
============================================================ */
let videoFile = null;

function loadVideo(file) {
    if (!file) return;
    videoFile = file;
    videoPreview.src = URL.createObjectURL(file);
}

videoInput.addEventListener("change", e => loadVideo(e.target.files[0]));
recordVideoInput.addEventListener("change", e => loadVideo(e.target.files[0]));



/* ============================================================
   EXTRACT FRAMES
============================================================ */
function extractFrames(file) {
    return new Promise(resolve => {
        const v = document.createElement("video");
        v.src = URL.createObjectURL(file);
        v.muted = true;

        v.onloadedmetadata = () => {
            const dur = v.duration;
            const times = [
                0,
                dur * 0.25,
                dur * 0.50,
                dur * 0.75,
                Math.max(0, dur - 0.15)
            ];

            const frames = [];
            const canvas = document.createElement("canvas");
            const ctx = canvas.getContext("2d");

            let i = 0;
            function snap() {
                if (i >= times.length) return resolve(frames);
                v.currentTime = times[i];

                v.onseeked = () => {
                    canvas.width = v.videoWidth;
                    canvas.height = v.videoHeight;

                    ctx.drawImage(v, 0, 0);
                    canvas.toBlob(b => {
                        frames.push(b);
                        i++;
                        snap();
                    }, "image/jpeg", 0.85);
                };
            }
            snap();
        };
    });
}



/* ============================================================
   ANALYZE VIDEO
============================================================ */
document.getElementById("analyzeVideoBtn").addEventListener("click", async () => {

    if (!videoFile) return showToast("Upload video first");

    const out = document.getElementById("videoOutput");
    out.textContent = "Extracting frames…";

    const frames = await extractFrames(videoFile);
    let descriptions = [];

    out.textContent = "Analyzing frames…";

    for (const frame of frames) {
        const base64 = await toBase64(frame);

        const desc = await callAI([
            {
                role: "user",
                content: [
                    { type:"text", text:"Describe ONLY what you see in this frame." },
                    { type:"image_url", image_url:{ url:"data:image/jpeg;base64,"+base64 }}
                ]
            }
        ]);

        descriptions.push(desc);
    }

    out.textContent = "Summarizing…";

    const final = await callAI([
        { role:"user", content:"Combine these into one summary:\n"+descriptions.join("\n") }
    ]);

    out.textContent = final;
    showToast("Done");

});



/* ============================================================
   TEXT TO SPEECH
============================================================ */
function speak(text, btn) {
    if (!text.trim()) return;

    const u = new SpeechSynthesisUtterance(text);
    u.lang = "en-US";
    u.rate = 1;

    btn.textContent = "⏹ Stop";

    u.onend = () => {
        btn.textContent = "🔊 Read";
    };

    speechSynthesis.speak(u);
}

document.getElementById("speakImgBtn").addEventListener("click", () =>
    speak(document.getElementById("imgOutput").textContent, speakImgBtn)
);
document.getElementById("speakVideoBtn").addEventListener("click", () =>
    speak(document.getElementById("videoOutput").textContent, speakVideoBtn)
);



/* ============================================================
   COPY
============================================================ */
function copyToClipboard(text, btn) {
    navigator.clipboard.writeText(text).then(() => {
        btn.textContent = "✔ Copied";
        setTimeout(() => (btn.textContent = "📋 Copy"), 1000);
    });
}

document.getElementById("copyImgBtn").addEventListener("click", () =>
    copyToClipboard(document.getElementById("imgOutput").textContent, copyImgBtn)
);
document.getElementById("copyVideoBtn").addEventListener("click", () =>
    copyToClipboard(document.getElementById("videoOutput").textContent, copyVideoBtn)
);
</script>
