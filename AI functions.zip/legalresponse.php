<?php
/*
============================================================
   BACKEND – CLEAN JSON PROXY FOR OPENAI
============================================================
*/
ob_start();

if (isset($_POST["action"]) && $_POST["action"] === "legal") {
    header("Content-Type: application/json; charset=utf-8");

    // --------------------------
    // Your API key
	
    $OPENAI_KEY = " PUT your API key here"; 

    $messages = json_decode($_POST["messages"] ?? "", true);

    if (!$messages) {
        ob_end_clean();
        echo json_encode(["backend_error" => "Invalid message format"]);
        exit;
    }

    $payload = json_encode([
        "model" => "gpt-4o-mini",
        "messages" => $messages
    ]);

    $ch = curl_init("https://api.openai.com/v1/chat/completions");
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            "Authorization: Bearer $OPENAI_KEY",
            "Content-Type: application/json"
        ],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS => $payload
    ]);

    $response = curl_exec($ch);
    $curl_err = curl_error($ch);
    curl_close($ch);

    ob_end_clean();

    if ($curl_err) {
        echo json_encode(["curl_error" => $curl_err]);
        exit;
    }

    echo $response;
    exit;
}

ob_end_clean();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>AI Legal Advisor</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icons/6.6.6/css/flag-icons.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
/* -------- GLOBAL -------- */
body {
    margin: 0;
    background: #eef2f7;
    padding-bottom: 90px;
    font-family: "Poppins", sans-serif;
    color: #1e293b;
}

/* -------- CARD -------- */
.card {
    background: #ffffff;
    padding: 22px;
    border-radius: 18px;
    margin: 18px;
    border: 1px solid #e3e7ef;
    box-shadow: 0 4px 14px rgba(0,0,0,0.05);
    transition: 0.25s;
}

.card:hover {
    box-shadow: 0 6px 18px rgba(0,0,0,0.08);
}

/* -------- BUTTONS -------- */
.btn {
    width: 50%;
    padding: 14px;
    border: 0;
    border-radius: 12px;
    background: linear-gradient(135deg, #2563eb, #1d4ed8);
    color: #fff;
    font-size: 17px;
    cursor: pointer;
    margin-top: 10px;
    font-weight: 600;
    transition: 0.25s ease;

    display: block;          /* ✅ يجعل العنصر بلوك */
    margin-left: auto;       /* ✅ يوسّط */
    margin-right: auto;      /* ✅ يوسّط */
}


.btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 14px rgba(37,99,235,0.35);
}

.btn:active {
    transform: scale(0.98);
}

/* -------- INPUT TEXTAREA -------- */
textarea {
    width: 90%;
    padding: 16px;
    min-height: 160px;
    border-radius: 14px;
    border: 1px solid #c4c9d4;
    font-family: "Poppins", sans-serif;
    font-size: 17px;
    background: #f8fafc;
    line-height: 1.6;
    transition: 0.25s;
}

textarea:focus {
    border-color: #2563eb;
    background: #fff;
    box-shadow: 0 0 0 3px rgba(37,99,235,0.18);
    outline: none;
}

/* -------- SELECT -------- */
select {
    width: 100%;
    padding: 12px;
    border-radius: 12px;
    font-size: 16px;
    border: 1px solid #c4c9d4;
    background: #f8fafc;
    transition: 0.25s;
}

select:focus {
    border-color: #2563eb;
    background: #fff;
    box-shadow: 0 0 0 3px rgba(37,99,235,0.18);
    outline: none;
}

/* -------- AI OUTPUT BOX -------- */
pre {
    white-space: pre-wrap;
    background: black;
    padding: 22px;
    border-radius: 14px;
    border: 1px solid #1e293b;
    min-height: 120px;
    max-height: 360px;
    overflow-y: auto;
    font-family: 'JetBrains Mono', monospace;
    color: lightgreen;
    font-size: 15px;
    line-height: 1.7;

    box-shadow: 0 6px 20px rgba(0,0,0,0.25),
                inset 0 0 12px rgba(255,255,255,0.04);
}

/* Scrollbar */
pre::-webkit-scrollbar {
    width: 8px;
}
pre::-webkit-scrollbar-track {
    background: #1e293b;
    border-radius: 10px;
}
pre::-webkit-scrollbar-thumb {
    background: #475569;
    border-radius: 10px;
}
pre::-webkit-scrollbar-thumb:hover {
    background: #64748b;
}

/* -------- RATING BARS -------- */
.rating-section {
    padding: 10px 0;
}

.rating-line {
    margin-bottom: 16px;
}

.rating-label {
    font-size: 15px;
    font-weight: 700;
    margin-bottom: 6px;
    color: #1e3a8a;
}

.rating-bar {
    width: 100%;
    height: 14px;
    background: #cbd5e1;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: inset 0 2px 4px rgba(0,0,0,0.15);
}

.rating-fill {
    height: 100%;
    border-radius: 12px;
    transition: width .55s ease;
    background: linear-gradient(90deg, #22c55e, #facc15, #ef4444);
    box-shadow: 0 0 8px rgba(0,0,0,0.2);
}

/* -------- NAVBAR -------- */
.navbar {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    height: 70px;
    background: #ffffff;
    border-top: 1px solid #d1d5db;
    display: flex;
    justify-content: space-around;
    align-items: center;
    box-shadow: 0 -4px 12px rgba(0,0,0,0.08);
}

.nav-item {
    text-align: center;
    color: #64748b;
    font-size: 14px;
    cursor: pointer;
    font-weight: 500;
    transition: 0.25s;
}

.nav-item i {
    display: block;
    font-size: 22px;
    margin-bottom: 4px;
}

.nav-item.active {
    color: #2563eb;
    font-weight: 700;
    transform: translateY(-2px);
}

/* -------- COUNTRY FLAG STYLING -------- */
.flag-option {
    background-repeat: no-repeat;
    padding-left: 42px;
    background-position: 10px center;
    background-size: 26px;
    height: 38px;
    display: flex;
    align-items: center;
}
</style>

</head>

<body>

<h2 style="text-align:center;margin-top:20px;color:#1e3a8a;"> ⚖️ AI Legal Advisor </h2>

<div class="card">
    <h3>Select Country</h3>
    <select id="country" style="width:100%;padding:12px;border-radius:10px;font-size:16px;">

        <option value="KW" class="flag-option"
            style="background-image:url('https://flagcdn.com/w40/kw.png')">
            🇰🇼 Kuwait
        </option>

        <option value="US" class="flag-option"
            style="background-image:url('https://flagcdn.com/w40/us.png')">
            🇺🇸 United States
        </option>

        <option value="FR" class="flag-option"
            style="background-image:url('https://flagcdn.com/w40/fr.png')">
            🇫🇷 France
        </option>

        <option value="GB" class="flag-option"
            style="background-image:url('https://flagcdn.com/w40/gb.png')">
            🇬🇧 United Kingdom
        </option>

    </select>
</div>

<div class="card">
    <h3>Describe Your Legal Issue</h3>
    <textarea id="legalText" placeholder="Explain your case..."></textarea>
</div>

<button class="btn" id="analyzeBtn">Analyze Case</button>

<div class="card">
    <h3>AI Legal Result</h3>
    <pre id="output">No result yet...</pre>
    <div id="ratingBars"></div>

    <button class="btn" id="speakBtn">🔊 Read</button>
    <button class="btn" style="background:#475569" id="copyBtn">📋 Copy</button>
</div>

<div class="navbar">
    <div class="nav-item active">
        <i class="fa fa-scale-balanced"></i>
        Legal
    </div>
    <div class="nav-item" onclick="window.location.href='pdfsummarize.php'">
        <i class="fa fa-file-pdf"></i>
        PDF
    </div>

    <div class="nav-item" onclick="window.location.href='advance.php'">
        <i class="fa fa-photo-video"></i>
        Image/Video
    </div>

</div>

<script>
/*
===========================================
   TEXT → RATING BAR PARSER
===========================================
*/
function renderBars(text) {
    const cont = document.getElementById("ratingBars");
    cont.innerHTML = "";

    const regex = /(.*?):\s*(\d{1,3})%/g;
    let m;

    while ((m = regex.exec(text)) !== null) {
        let label = m[1];
        let val = Number(m[2]);

        // Updated colors for the rating bars
        let color = "#b91c1c"; // Dark Red (Danger)
        if (val > 70) color = "#16a34a"; // Dark Green (Success)
        else if (val > 40) color = "#d97706"; // Dark Orange (Warning)

        cont.innerHTML += `
            <div class="rating-line">
                <div class="rating-label">${label}: ${val}%</div>
                <div class="rating-bar">
                    <div class="rating-fill" style="width:${val}%; background:${color};"></div>
                </div>
            </div>
        `;
    }
}

/*
===========================================
   CALL AI (Backend)
===========================================
*/
async function callAI(messages) {
    const res = await fetch("", {
        method: "POST",
        body: new URLSearchParams({
            action: "legal",
            messages: JSON.stringify(messages)
        })
    });

    const text = await res.text();
    let json;

    try {
        json = JSON.parse(text);
    } catch {
        return "Error: backend returned HTML or invalid JSON.";
    }

    // Handle potential errors from the backend before accessing choices
    if(json.curl_error) {
        return "cURL Error: " + json.curl_error;
    }
    if(json.backend_error) {
        return "Backend Error: " + json.backend_error;
    }

    return json.choices?.[0]?.message?.content || "No response from AI.";
}

/*
===========================================
   MAIN LOGIC
===========================================
*/
document.getElementById("analyzeBtn").onclick = async () => {

    let country = document.getElementById("country").value;
    let text = document.getElementById("legalText").value;

    if (!country) {
        alert("Select a country first.");
        return;
    }
    if (!text.trim()) {
        alert("Describe your legal case.");
        return;
    }

    const out = document.getElementById("output");
    out.textContent = "Analyzing legal case...";
    document.getElementById("ratingBars").innerHTML = "";

    // The prompt is the same, ensuring the AI outputs are well-structured for the new styles.
    const prompt = `
You are a professional legal advisor AI.
VERY IMPORTANT RULES:
- Detect the user's language.
- If the user writes in Arabic → reply ONLY in Arabic.
- If the user writes in English → reply ONLY in English.
- Never switch languages.

Country selected: ${country}

Analyze the case and provide:
1. Name of the most relevant law + article number (best estimate)
2. Penalty
3. User rights
Percentage rate bars of risk and confidence.
- No long paragraphs
- Ensure the percentage rates are placed at the end of the response text outside of any code blocks for the parser to work.

User case: ${text}
`;

    const result = await callAI([
        { role: "user", content: prompt }
    ]);

    out.textContent = result;
    renderBars(result);
};

/*
===========================================
   COPY
===========================================
*/
document.getElementById("copyBtn").onclick = () => {
    navigator.clipboard.writeText(
        document.getElementById("output").textContent
    );
};

/*
===========================================
   SPEAK — Auto Language + Stop/Start Toggle
===========================================
*/
let currentUtterance = null;

function speak(text, btn) {
    if (!text.trim()) return;

    // If already speaking → STOP
    if (speechSynthesis.speaking || speechSynthesis.paused) {
        speechSynthesis.cancel();
        btn.textContent = "🔊 Read";
        return;
    }

    currentUtterance = new SpeechSynthesisUtterance(text);
    currentUtterance.rate = 1;

    // Detect language automatically
    if (/[\u0600-\u06FF]/.test(text)) {
        currentUtterance.lang = "ar-SA"; // Arabic
    } else {
        currentUtterance.lang = "en-US"; // English
    }

    currentUtterance.onstart = () => {
        btn.textContent = "⏹ Stop";
    };

    currentUtterance.onend = () => {
        btn.textContent = "🔊 Read";
    };

    speechSynthesis.speak(currentUtterance);
}

/* Attach to correct button */
document.getElementById("speakBtn").onclick = function () {
    speak(document.getElementById("output").textContent, this);
};
</script>

</body>
</html>