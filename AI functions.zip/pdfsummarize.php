<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>AI PDF/TXT Summarizer + Q&A — Friendly</title>

<!-- Icons & pdf.js -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.16.105/pdf.min.js"></script>

<style>
  :root{
    --bg:#eef6ff;
    --card:#ffffff;
    --accent:#2563eb;
    --muted:#6b7280;
    --success:#16a34a;
    --danger:#dc2626;
    --sidebar:#0b1220;
  }
  body{
    margin:0;
    font-family:Inter,Segoe UI,Arial,sans-serif;
    background:var(--bg);
    color:#0f172a;
    display:flex;
    min-height:100vh;
  }

  /* Layout: main + sidebar */
  .main {
    flex:1;
    max-width:900px;
    padding:28px;
  }
  .sidebar {
    width:360px;
    background:var(--sidebar);
    color:#e6eef8;
    padding:18px;
    box-shadow: -6px 0 24px rgba(11,17,32,0.12);
    display:flex;
    flex-direction:column;
  }

  header h1{
    margin:0 0 6px 0;
    font-size:20px;
    color:var(--accent);
  }
  header p { margin:0 0 18px 0; color:var(--muted); }

  .card{
    background:var(--card);
    border-radius:12px;
    padding:14px;
    margin-bottom:16px;
    box-shadow:0 6px 18px rgba(16,24,40,0.03);
  }

  .file-label{
    display:block;
    padding:10px 12px;
    background:#0f172a;
    color:#fff;
    border-radius:8px;
    text-align:center;
    cursor:pointer;
  }
  .small { font-size:13px; color:var(--muted); margin-top:8px; }

  .btn{
    width:100%;
    padding:12px;
    background:var(--accent);
    color:#fff;
    border:none;
    border-radius:10px;
    cursor:pointer;
    font-weight:600;
    margin-top:8px;
  }
  .btn.secondary{ background:#059669; }
  .row { display:flex; gap:10px; }
  input[type="text"], textarea {
    width:100%;
    padding:10px;
    border-radius:8px;
    border:1px solid #e6eef8;
    box-sizing:border-box;
  }
  pre{
    white-space:pre-wrap;
    background:#f6fbff;
    padding:12px;
    border-radius:8px;
    min-height:68px;
    border:1px solid #e6eef8;
  }

  /* Sidebar specifics */
  .sidebar h3{ margin:0 0 10px 0; color:#bcd6ff; }
  #logBox{
    background:transparent;
    color:#e6eef8;
    padding:10px;
    border-radius:8px;
    border:1px solid rgba(255,255,255,0.04);
    flex:1;
    overflow:auto;
    font-family:monospace;
    font-size:13px;
  }
  .log-controls{ display:flex; gap:8px; margin-top:10px; }
  .log-btn{ flex:1; padding:8px; border-radius:8px; border:1px solid rgba(255,255,255,0.06); background:transparent; color:#e6eef8; cursor:pointer; }

  /* toast */
  #toast-container{ position:fixed; right:20px; bottom:20px; z-index:2000; }
  .toast{ background:#111827; color:#fff; padding:10px 14px; border-radius:10px; margin-top:8px; display:flex; gap:10px; align-items:center; box-shadow:0 10px 30px rgba(2,6,23,0.4); }

  /* responsive: collapse sidebar under 980px */
  @media (max-width:980px){
    .sidebar{ position:fixed; right:0; top:0; bottom:0; width:92%; max-width:420px; transform:translateX(100%); transition:transform .28s; z-index:1200; }
    .sidebar.open{ transform:translateX(0); }
    .main{ padding:18px; }
    .sidebar-toggle{ position:fixed; right:16px; bottom:90px; background:var(--accent); color:#fff; padding:12px;border-radius:999px; box-shadow:0 8px 28px rgba(37,99,235,0.18); z-index:1300; border:none; }
  }
  
  
  .bottom-navbar {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    background: #ffffff;
    border-top: 1px solid #ddd;
    display: flex;
    justify-content: space-around;
    padding: 10px 0;
    z-index: 9999;
}

.bottom-navbar .nav-item {
    text-align: center;
    flex: 1;
    cursor: pointer;
    color: #6b7280; /* gray-500 */
    font-size: 13px;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.bottom-navbar .nav-item i {
    font-size: 18px;
    margin-bottom: 2px;
}

/* Active state */
.bottom-navbar .nav-item.active {
    color: #2563eb; /* blue-600 */
    font-weight: bold;
}

</style>
</head>
<body>

  <div class="main">
    <header>
      <h1>📄 AI PDF / TXT Summarizer + Q&A</h1>
      <p class="small">Friendly interface — upload a file, ask questions right away (no need to summarize first). Interaction log appears in the right sidebar.</p>
    </header>

    <div class="card">
      <label class="file-label" for="fileInput"><i class="fa fa-upload"></i> Upload PDF or TXT</label>
      <input id="fileInput" type="file" accept=".pdf,.txt" style="display:none">
      <p id="fileName" class="small">No file selected.</p>
      <p class="small">Note: The system extracts the text automatically after upload. You can ask questions immediately.</p>
    </div>

    <div class="card">
      <button id="summarizeBtn" class="btn"><i class="fa fa-file-lines"></i> Generate Summary</button>
      <div style="margin-top:12px">
        <h4 style="margin:0 0 8px 0">Summary</h4>
        <pre id="output">No summary yet...</pre>
      </div>
    </div>

    <div class="card">
      <h4 style="margin:0 0 8px 0">Ask about the uploaded file</h4>
      <input id="questionInput" type="text" placeholder="Ask something here about the file.. " />
      <button id="askBtn" class="btn" style="margin-top:10px"><i class="fa fa-robot"></i> Ask</button>
      <div style="margin-top:12px">
        <h4 style="margin:0 0 8px 0">Answer</h4>
        <pre id="answerBox">No answer yet...</pre>
      </div>
    </div>

    <div class="card" style="text-align:center;">
      <p class="small"> &lt;/&gt; Developer: Mohammed Basim </p>
    </div>
  </div>

  <!-- Sidebar -->
  <aside class="sidebar" id="sidebar">
    <div style="display:flex;gap:12px;align-items:center;margin-bottom:14px">
      <div style="flex:1">
        <h3>Activity Log</h3>
        <div class="small" style="color:#9fbaff">All events appear here in friendly format</div>
      </div>
      <button id="closeSidebar" title="Close" style="background:transparent;border:none;color:#bcd6ff;cursor:pointer"><i class="fa fa-xmark"></i></button>
    </div>

    <pre id="logBox">No interactions yet...</pre>

    <div class="log-controls">
      <button id="clearLogBtn" class="log-btn"><i class="fa fa-trash"></i> Clear</button>
      <button id="exportLogBtn" class="log-btn"><i class="fa fa-download"></i> Export</button>
    </div>

    <div style="margin-top:14px;color:#9fbaff;font-size:13px">
      <div style="margin-bottom:6px"><strong>Legend:</strong></div>
      <div style="font-size:13px; color:#cfe3ff">USER • actions you performed</div>
      <div style="font-size:13px; color:#b6f2c0">SYSTEM • extraction / process messages</div>
      <div style="font-size:13px; color:#ffd9a8">AI • model responses</div>
    </div>
  </aside>

  <!-- mobile toggle button -->
  <button class="sidebar-toggle" id="sidebarToggle" title="Open activity log" style="display:none"><i class="fa fa-list"></i></button>

  <div id="toast-container"></div>
  
  
  <!-- Bottom Navbar -->
<div class="bottom-navbar">

   

    <div class="nav-item" onclick="window.location.href='advance.php'" id="nav-pdf">
    <i class="fa fa-image"></i> 
    <span>image/video</span>
</div>

    <div class="nav-item" onclick="window.location.href='legalresponse.php'" id="nav-legal">
        <i class="fa fa-balance-scale"></i>
        <span>Legal</span>
    </div>

</div>


<script>
/* ============= CONFIG ============= */
    $OPENAI_KEY = " PUT your API key"; // your API key here
/* ================================== */

const fileInput = document.getElementById('fileInput');
const fileNameEl = document.getElementById('fileName');
const outputEl = document.getElementById('output');
const answerBox = document.getElementById('answerBox');
const questionInput = document.getElementById('questionInput');
const summarizeBtn = document.getElementById('summarizeBtn');
const askBtn = document.getElementById('askBtn');
const logBox = document.getElementById('logBox');
const clearLogBtn = document.getElementById('clearLogBtn');
const exportLogBtn = document.getElementById('exportLogBtn');
const sidebar = document.getElementById('sidebar');
const sidebarToggle = document.getElementById('sidebarToggle');
const closeSidebar = document.getElementById('closeSidebar');
const toastContainer = document.getElementById('toast-container');

let selectedFile = null;
let extractedText = "";
let interactionLog = [];

/* Helpers: toast + log */
function showToast(message){
  const t = document.createElement('div');
  t.className = 'toast';
  t.innerHTML = `<i class="fa fa-info-circle"></i><div>${message}</div>`;
  toastContainer.appendChild(t);
  setTimeout(()=> t.remove(), 3500);
}

function addLog(kind, text){
  const now = new Date();
  const stamp = now.toLocaleTimeString();
  const friendly = `[${stamp}] ${kind.toUpperCase()}: ${text}`;
  if(logBox.textContent.trim() === "No interactions yet...") logBox.textContent = "";
  logBox.textContent += friendly + "\n";
  logBox.scrollTop = logBox.scrollHeight;
  interactionLog.push({ ts: now.toISOString(), kind, text });
}

/* Responsive sidebar */
function updateSidebarToggle(){
  if(window.innerWidth <= 980){
    sidebar.classList.remove('open');
    sidebarToggle.style.display = 'block';
  } else {
    sidebar.classList.add('open');
    sidebarToggle.style.display = 'none';
  }
}
window.addEventListener('resize', updateSidebarToggle);
updateSidebarToggle();
sidebarToggle.addEventListener('click', ()=> sidebar.classList.add('open'));
closeSidebar.addEventListener('click', ()=> sidebar.classList.remove('open'));

/* Simple language detection */
function detectLanguage(text){
    if(/[\u0600-\u06FF]/.test(text)) return 'ar'; // Arabic
    return 'en'; // default English
}

/* File selection -> automatic extraction */
fileInput.addEventListener('change', async (e) => {
  selectedFile = e.target.files?.[0] || null;
  fileNameEl.textContent = selectedFile ? `File: ${selectedFile.name}` : 'No file selected.';
  addLog('user', `Selected file: ${selectedFile ? selectedFile.name : 'none'}`);
  if(!selectedFile) return;

  try {
    addLog('system', 'Starting text extraction...');
    showToast('Extracting text from uploaded file...');
    if(selectedFile.name.toLowerCase().endsWith('.pdf')){
      extractedText = await extractPdfText(selectedFile);
    } else {
      extractedText = await selectedFile.text();
    }
    addLog('system', `Extraction finished — ${extractedText.length} characters`);
    showToast('Text extracted — you can ask a question now!');
  } catch(err){
    console.error(err);
    addLog('system', 'Extraction failed: ' + (err.message || err));
    showToast('Failed to extract text (check console)');
    extractedText = "";
  }
});

/* pdf.js extraction */
async function extractPdfText(file){
  if(!pdfjsLib.GlobalWorkerOptions.workerSrc){
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.16.105/pdf.worker.min.js';
  }
  const arrayBuffer = await file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument({data: arrayBuffer}).promise;
  let full = "";
  for(let i=1; i<=pdf.numPages; i++){
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    full += content.items.map(it => it.str).join(' ') + "\n\n";
  }
  return full;
}

/* Summarize button */
summarizeBtn.addEventListener('click', async () => {
  addLog('user', 'Clicked "Generate Summary"');
  if(!selectedFile || !extractedText){
    addLog('system','Cannot summarize: no extracted text');
    showToast('Please upload a file and wait for extraction first.');
    return;
  }
  outputEl.textContent = 'Generating summary...';
  addLog('system','Requesting summary from AI...');
  try {
    const summary = await callOpenAIForSummary(extractedText);
    outputEl.textContent = summary || 'No summary returned.';
    addLog('ai','Summary generated.');
    showToast('Summary ready ✅');
  } catch(err){
    console.error(err);
    outputEl.textContent = 'Summary error: ' + (err.message || err);
    addLog('system','Summary failed: ' + (err.message || err));
    showToast('Failed to generate summary (check console).');
  }
});

/* Ask button */
askBtn.addEventListener('click', async () => {
  const q = questionInput.value.trim();
  addLog('user', `Asked: ${q || '[empty]'}`);
  if(!q){
    showToast('Please type a question first.');
    addLog('system','Ask aborted: empty question');
    return;
  }
  if(!selectedFile || !extractedText){
    showToast('Please upload a file and wait for extraction first.');
    addLog('system','Ask aborted: no extracted text');
    return;
  }
  answerBox.textContent = 'Thinking...';
  addLog('system','Sending question to AI (using extracted file context)...');
  try {
    const ans = await callOpenAIForQnA(extractedText, q);
    answerBox.textContent = ans || 'No answer found.';
    addLog('ai','Answered the question.');
    showToast('Answer received ✅');
  } catch(err){
    console.error(err);
    answerBox.textContent = 'Error: ' + (err.message || err);
    addLog('system','Q&A failed: ' + (err.message || err));
    showToast('Failed to get answer (check console).');
  }
});

/* Clear / Export log */
clearLogBtn.addEventListener('click', () => {
  interactionLog = [];
  logBox.textContent = 'No interactions yet...';
  addLog('system','User cleared the activity log');
});
exportLogBtn.addEventListener('click', () => {
  const blob = new Blob([JSON.stringify(interactionLog, null, 2)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = 'activity_log.json';
  document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
  addLog('system','User exported the activity log');
});

/* ===== OpenAI calls ===== */
async function callOpenAIForSummary(text){
  const lang = detectLanguage(text);
  const systemPrompt = lang === 'ar' 
      ? "You are a helpful summarizer. Summarize the following text in Arabic in a concise, friendly style."
      : "You are a helpful summarizer. Summarize the following text in English in a concise, friendly style.";
  
  const payload = {
    model: "gpt-4o-mini",
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: text }
    ],
    temperature:0.2,
    max_tokens:800
  };
  
  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method:'POST',
    headers:{
      'Content-Type':'application/json',
      'Authorization': `Bearer ${OPENAI_KEY}`
    },
    body: JSON.stringify(payload)
  });
  
  if(!res.ok) throw new Error(`OpenAI API error: ${res.status}`);
  const j = await res.json();
  return j.choices?.[0]?.message?.content ?? '';
}

async function callOpenAIForQnA(contextText, question){
    const docLang = detectLanguage(contextText);   // لغة المستند
    const userLang = detectLanguage(question);     // لغة السؤال

    let systemMsg = "";

    if(docLang === userLang){
        // نفس اللغة → استخدم المحتوى مباشرة
        systemMsg = `You are a helpful assistant. Answer ONLY using the provided document content.
If the document does not contain the answer, reply:
${userLang === 'ar' ? "'المستند لا يحتوي على معلومات كافية للإجابة على هذا السؤال.'" : "'The document does not contain enough information to answer this question.'"}
Keep the tone friendly and concise.
Answer in the SAME language as the question.`;
    } else {
        // لغات مختلفة → ترجم السؤال إلى لغة المستند، ثم أجب بالعودة إلى لغة السؤال
        systemMsg = `You are a helpful assistant. The document is in ${docLang === 'ar' ? "Arabic" : "English"} and the user question is in ${userLang === 'ar' ? "Arabic" : "English"}.
Answer ONLY using the provided document content.
If the document does not contain the answer, reply:
${userLang === 'ar' ? "'المستند لا يحتوي على معلومات كافية للإجابة على هذا السؤال.'" : "'The document does not contain enough information to answer this question.'"}
You must understand the user's question language, retrieve the answer from the document language, and respond in the SAME language as the question.
Keep the tone friendly and concise.`;
    }

    const payload = {
        model: "gpt-4o-mini",
        messages: [
            { role: "system", content: systemMsg },
            { role: "assistant", content: contextText },
            { role: "user", content: question }
        ],
        temperature: 0.0,
        max_tokens: 800
    };

    const res = await fetch("https://api.openai.com/v1/chat/completions", {
        method:'POST',
        headers:{
            'Content-Type':'application/json',
            'Authorization': `Bearer ${OPENAI_KEY}`
        },
        body: JSON.stringify(payload)
    });

    if(!res.ok) throw new Error(`OpenAI API error: ${res.status}`);
    const j = await res.json();
    return j.choices?.[0]?.message?.content ?? '';
}

  
</script>


</body>
</html>
